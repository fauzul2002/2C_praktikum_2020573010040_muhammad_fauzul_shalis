<?php
    $conn = mysqli_connect("localhost", "root", "", "sipbar_2c") or die ("koneksi gagal");
?>